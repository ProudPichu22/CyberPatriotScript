Invoke-WebRequest -Uri https://aka.ms/get-winget -OutFile AppInstaller.msixbundle
Add-AppxPackage -Path AppInstaller.msixbundle
